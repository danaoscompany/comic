<?php

declare(strict_types=1);

namespace PHPHtmlParser\Exceptions\Tag;

/**
 * Class AttributeNotFoundException.
 */
class AttributeNotFoundException extends \Exception
{
}
