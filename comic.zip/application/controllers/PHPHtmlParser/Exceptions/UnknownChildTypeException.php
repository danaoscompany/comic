<?php

declare(strict_types=1);

namespace PHPHtmlParser\Exceptions;

use Exception;

/**
 * Class UnknownChildTypeException.
 */
final class UnknownChildTypeException extends Exception
{
}
