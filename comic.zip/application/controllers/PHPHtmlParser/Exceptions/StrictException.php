<?php

declare(strict_types=1);

namespace PHPHtmlParser\Exceptions;

use Exception;

/**
 * Class StrictException.
 */
final class StrictException extends Exception
{
}
