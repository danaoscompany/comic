<?php

declare(strict_types=1);

namespace PHPHtmlParser\Exceptions;

use Exception;

/**
 * Class ParentNotFoundException.
 */
final class ParentNotFoundException extends Exception
{
}
